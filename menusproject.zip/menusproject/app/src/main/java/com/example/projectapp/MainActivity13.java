package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity13 extends AppCompatActivity {
    public void thankyou(View view)
    {
        Intent I = new Intent(getApplicationContext(),MainActivity14.class);
        startActivity(I);
    }
    public void radioselection(View view){
        RadioButton btn1 = (RadioButton)findViewById(R.id.rad1);
        RadioButton btn2 = (RadioButton)findViewById(R.id.rad2);
        RadioButton btn3 = (RadioButton)findViewById(R.id.rad3);
        RadioButton btn4 = (RadioButton)findViewById(R.id.rad4);
        RadioButton btn5 = (RadioButton)findViewById(R.id.rad5);

        if(view.getId()==R.id.rad1)
        {
            btn2.setChecked(false);
            btn3.setChecked(false);
            btn4.setChecked(false);
            btn5.setChecked(false);
        }
        else if(view.getId()==R.id.rad2)
        {
            btn1.setChecked(false);
            btn3.setChecked(false);
            btn4.setChecked(false);
            btn5.setChecked(false);
        }
        else if(view.getId()==R.id.rad3)
        {
            btn1.setChecked(false);
            btn2.setChecked(false);
            btn4.setChecked(false);
            btn5.setChecked(false);
        }
        else if(view.getId()==R.id.rad4)
        {
            btn1.setChecked(false);
            btn3.setChecked(false);
            btn2.setChecked(false);
            btn5.setChecked(false);
        }
        else if(view.getId()==R.id.rad5)
        {
            btn1.setChecked(false);
            btn3.setChecked(false);
            btn4.setChecked(false);
            btn2.setChecked(false);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main13);
    }
}