package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity15 extends AppCompatActivity {
public void updatedbmc(View view){
    EditText nameee = (EditText)findViewById(R.id.nameup);

    String name = nameee.getText().toString();

    String id =getIntent().getStringExtra("id");

    MenusDataBase upmacdo =new MenusDataBase(getApplicationContext());
    upmacdo.updatemac(Integer.parseInt(id),name);
    Toast.makeText(getApplicationContext(),"Item updated to Mcdonalds menu",Toast.LENGTH_LONG).show();


}
    public void updatedbkfc(View view){
        EditText nameee = (EditText)findViewById(R.id.nameup);

        String name = nameee.getText().toString();

        String id =getIntent().getStringExtra("id");

        MenusDataBase upkfc =new MenusDataBase(getApplicationContext());
        upkfc.updatekfc  (Integer.parseInt(id),name);
        Toast.makeText(getApplicationContext(),"Item updated to kfc menu",Toast.LENGTH_LONG).show();


    }
    public void updatedbhut(View view){
        EditText nameee = (EditText)findViewById(R.id.nameup);

        String name = nameee.getText().toString();

        String id =getIntent().getStringExtra("id");

        MenusDataBase uphut =new MenusDataBase(getApplicationContext());
        uphut.updatehut  (Integer.parseInt(id),name);
        Toast.makeText(getApplicationContext(),"Item updated to pizza hut menu",Toast.LENGTH_LONG).show();


    }
    public void updatedbmazen(View view){
        EditText nameee = (EditText)findViewById(R.id.nameup);

        String name = nameee.getText().toString();

        String id =getIntent().getStringExtra("id");

        MenusDataBase upmazen =new MenusDataBase(getApplicationContext());
        upmazen.updatemazen  (Integer.parseInt(id),name);
        Toast.makeText(getApplicationContext(),"Item updated to abo mazen menu",Toast.LENGTH_LONG).show();


    }
    public void updatedbfila(View view){
        EditText nameee = (EditText)findViewById(R.id.nameup);

        String name = nameee.getText().toString();

        String id =getIntent().getStringExtra("id");

        MenusDataBase upfila =new MenusDataBase(getApplicationContext());
        upfila.updatefila  (Integer.parseInt(id),name);
        Toast.makeText(getApplicationContext(),"Item updated to chicken fila menu",Toast.LENGTH_LONG).show();


    }
    public void updatedbprince(View view){
        EditText nameee = (EditText)findViewById(R.id.nameup);

        String name = nameee.getText().toString();

        String id =getIntent().getStringExtra("id");

        MenusDataBase upprince =new MenusDataBase(getApplicationContext());
        upprince.updateelrince  (Integer.parseInt(id),name);
        Toast.makeText(getApplicationContext(),"Item updated to elprince menu",Toast.LENGTH_LONG).show();


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main15);
        String name =getIntent().getStringExtra("name");

        EditText nameee = (EditText)findViewById(R.id.nameup);

        nameee.setText(name);


    }
}