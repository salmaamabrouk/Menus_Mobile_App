package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

public void showmac(View view){
    Intent I= new Intent(getBaseContext(),MainActivity6.class);
    startActivity(I);
}
    public void showkfc(View view){
        Intent I= new Intent(getBaseContext(),MainActivity7.class);
        startActivity(I);
    }
    public void showpizzahut(View view){
        Intent I= new Intent(getBaseContext(),MainActivity8.class);
        startActivity(I);
    }
    public void showmazen(View view){
        Intent I= new Intent(getBaseContext(),MainActivity9.class);
        startActivity(I);
    }
    public void showchickenfila(View view){
        Intent I= new Intent(getBaseContext(),MainActivity10.class);
        startActivity(I);
    }
    public void showprince(View view){
        Intent I= new Intent(getBaseContext(),MainActivity11.class);
        startActivity(I);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        ArrayList<String> resturants = new ArrayList<>();
        resturants.add("Mcdonald's");
        resturants.add("KFC");
        resturants.add("Pizza Hut");
        resturants.add("Abo Mazen");
        resturants.add("Chicken Fila");
        resturants.add("Elprince");
        ArrayAdapter dataadapter= new ArrayAdapter(this,android.R.layout.simple_list_item_1,resturants);
        ListView listV = (ListView) findViewById(R.id.listview);
        listV.setAdapter(dataadapter);
      listV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          @Override
          public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

          }
      });
    }
}