 package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

 public class MainActivity3 extends AppCompatActivity {
     public void addtomcdonalds(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to mcdonalds menu",Toast.LENGTH_LONG).show();


     }
     public void addtkfc(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem1(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to kfc menu",Toast.LENGTH_LONG).show();


     }
     public void addtopizzahut(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem2(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to pizza hut menu",Toast.LENGTH_LONG).show();


     }
     public void addtoabomazen(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem3(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to abo mazen menu",Toast.LENGTH_LONG).show();


     }
     public void addtochickenfila(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem4(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to abo chicken fila menu",Toast.LENGTH_LONG).show();


     }
     public void addtoeprince(View view){
         EditText nam = (EditText)findViewById(R.id.nametxt);
         EditText pri = (EditText)findViewById(R.id.pricetxt);
         MenusDataBase newitem= new MenusDataBase(this);
         newitem.createnewitem5(nam.getText().toString(), Integer.parseInt(pri.getText().toString()));
         Toast.makeText(getApplicationContext(),"item added to elprince menu",Toast.LENGTH_LONG).show();


     }
     public void showmenustoupdate(View view)
     {
         Intent I = new Intent(getApplicationContext(),MainActivity5.class);
         startActivity(I);
     }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
}