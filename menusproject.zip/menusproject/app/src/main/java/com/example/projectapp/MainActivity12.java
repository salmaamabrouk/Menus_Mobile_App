package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity12 extends AppCompatActivity {
    public void signupfinished(View view)
    {
        Intent I= new Intent(getApplicationContext(),MainActivity5.class);
             startActivity(I);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
        ArrayList<String> choice = new <String> ArrayList();
        choice.add("10");
        choice.add("11");
        choice.add("12");
        choice.add("13");
        choice.add("14");
        choice.add("15");
        choice.add("16");
        choice.add("17");
        choice.add("18");
        choice.add("19");
        choice.add("20");
        choice.add("21");
        choice.add("22");
        choice.add("23");
        choice.add("24");
        choice.add("25");
        choice.add("26");
        choice.add("27");
        choice.add("28");
        choice.add("29");
        choice.add("30");
        choice.add("31");
        choice.add("32");
        choice.add("33");
        choice.add("34");
        choice.add("35");
        choice.add("36");
        choice.add("37");
        choice.add("38");
        choice.add("39");
        choice.add("40");
        choice.add("41");
        choice.add("42");
        choice.add("43");
        choice.add("44");
        choice.add("45");
        choice.add("46");
        choice.add("47");
        choice.add("48");
        choice.add("49");
        choice.add("50");
        ArrayAdapter dataadapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,choice);
        dataadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner S=(Spinner)findViewById(R.id.spinner3);
        S.setAdapter(dataadapter);
    }
}