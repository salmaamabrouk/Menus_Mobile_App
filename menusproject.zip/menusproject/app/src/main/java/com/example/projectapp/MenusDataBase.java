package com.example.projectapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MenusDataBase extends SQLiteOpenHelper {
    static String DataBaseName = "elmenus";
    SQLiteDatabase menuusDatabase;
    // create database
    public MenusDataBase(@Nullable Context context) {
        super(context, DataBaseName, null, 1 );

    }
    // create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table mcdonalds (id integer Primary Key,"+"name text not null,"+"price int not null)");
        db.execSQL("create table kfc (id integer Primary Key,"+"name text not null,"+"price int not null)");
        db.execSQL("create table pizzahut (id integer Primary Key,"+"name text not null,"+"price int not null)");
        db.execSQL("create table abomazen (id integer Primary Key,"+"name text not null,"+"price int not null)");
        db.execSQL("create table chickenfila (id integer Primary Key,"+"name text not null,"+"price int not null)");
        db.execSQL("create table elprince (id integer Primary Key,"+"name text not null,"+"price int not null)");


    }
    //upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists mcdonalds");
        onCreate(db);
        db.execSQL("drop table if exists kfc");
        onCreate(db);
        db.execSQL("drop table if exists pizzahut");
        onCreate(db);
        db.execSQL("drop table if exists mcdonalds");
        onCreate(db);
        db.execSQL("drop table if exists abomazen");
        onCreate(db);
        db.execSQL("drop table if exists chickenfila");
        onCreate(db);
        db.execSQL("drop table if exists elprince");
        onCreate(db);
    }
    public void createnewitem(String name,int price)
    {
        ContentValues row1 = new ContentValues();
        row1.put("name",name);
        row1.put("price",price);

        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("mcdonalds",null, row1);
        menuusDatabase.close();
    }
    public void createnewitem1(String name,int price){
        ContentValues row2 = new ContentValues();
        row2.put("name",name);
        row2.put("price",price);
        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("kfc",null, row2);
        menuusDatabase.close();
    }
    public void createnewitem2(String name,int price){
        ContentValues row3 = new ContentValues();
        row3.put("name",name);
        row3.put("price",price);
        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("pizzahut",null, row3);
        menuusDatabase.close();
    }
    public void createnewitem3(String name,int price){
        ContentValues row4 = new ContentValues();
        row4.put("name",name);
        row4.put("price",price);
        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("abomazen",null, row4);
        menuusDatabase.close();
    }
    public void createnewitem4(String name,int price){
        ContentValues row5 = new ContentValues();
        row5.put("name",name);
        row5.put("price",price);
        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("chickenfila",null, row5);
        menuusDatabase.close();
    }
    public void createnewitem5(String name,int price){
        ContentValues row6 = new ContentValues();
        row6.put("name",name);
        row6.put("price",price);
        menuusDatabase= getWritableDatabase();
        menuusDatabase.insert("elprince",null, row6);
        menuusDatabase.close();
    }
    public Cursor fetchallitems()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("mcdonalds",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchallitems1()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("kfc",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchallitems2()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("pizzahut",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchallitems3()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("abomazen",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchallitems4()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("chickenfila",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchallitems5()
    {
        menuusDatabase = getReadableDatabase();
        String [] rowdetails = {"name","price","id"};
        Cursor cursor = menuusDatabase.query("elprince",rowdetails,null,null,null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        menuusDatabase.close();
        return cursor;
    }
    public Cursor fetchcertainmac(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("mcdonalds",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchcertainkfc(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("kfc",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchcertainhut(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("pizzahut",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchcertainmazen(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("abomazen",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchcertainfila(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("chickenfila",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchcertainprince(int pos){
        menuusDatabase= getReadableDatabase();
        String[] rowdetails= {"name","price"};
        Cursor cursor = menuusDatabase.query("elprince",rowdetails,"id = ?",new String[] {Integer.toString(pos)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public void updatemac(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("mcdonalds",row,"id = ?",new String[] {Integer.toString(id)});
    }
    public void updatekfc(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("kfc",row,"id = ?",new String[] {Integer.toString(id)});
    }
    public void updatehut(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("pizzahut",row,"id = ?",new String[] {Integer.toString(id)});
    }
    public void updatemazen(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("abomazen",row,"id = ?",new String[] {Integer.toString(id)});
    }
    public void updatefila(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("chickenfila",row,"id = ?",new String[] {Integer.toString(id)});
    }
    public void updateelrince(int id, String name){
        ContentValues row = new ContentValues();
        row.put("name",name);

        menuusDatabase = getReadableDatabase();
        menuusDatabase.update("elprince",row,"id = ?",new String[] {Integer.toString(id)});
    }
}
