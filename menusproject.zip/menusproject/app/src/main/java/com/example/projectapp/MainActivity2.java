package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ArrayList<String> choice = new <String> ArrayList();
        choice.add("");
        choice.add("database administrator");
        choice.add("user");
        ArrayAdapter dataadapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,choice);
        dataadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner S=(Spinner)findViewById(R.id.spinner);

        S.setAdapter(dataadapter);
        S.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch(position)
                {


                    case 1:
                        Intent x= new Intent(getApplicationContext(),MainActivity3.class);
                        startActivity(x);
                        break;
                    case 2:
                        Intent y= new Intent(getApplicationContext(),MainActivity4.class);
                        startActivity(y);
                        break;

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}