package com.example.projectapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
public void signup(View view)
{
    Intent I= new Intent(getApplicationContext(),MainActivity12.class);
            startActivity(I);
}

    public void login(View view) {
        EditText username = (EditText)findViewById(R.id.name);
        EditText password = (EditText)findViewById(R.id.pass);
        if (username.getText().toString().equals("user") && password.getText().toString().equals("user")) {
            Intent I = new Intent(getBaseContext(), MainActivity5.class);
            startActivity(I);

        } else {
            Toast.makeText(getApplicationContext(), "Wrong Password Please Try Again", Toast.LENGTH_LONG).show();

        }
    }


        @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }
}